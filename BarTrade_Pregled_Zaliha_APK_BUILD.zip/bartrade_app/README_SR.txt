BARTRADE – PREGLED ZALIHA PO LOKACIJAMA
========================================

ŠTA JE UKLJUČENO
- Web aplikacija prilagođena telefonu i računaru (www/)
- Početni podaci iz dostavljenog Excel fajla: 1.442 reda
- BarTrade logo
- Android Studio projekat (android/), WebView omotač

FUNKCIJE
- Pretraga po šifri, nazivu artikla, barkodu i lokaciji
- Filter po lokaciji i jedinici mjere
- Tabela sa lokacijom, šifrom, nazivom, stanjem, JM, rezervacijom i rokom
- Korekcija količine za odabrani red
- Čuvanje podataka i korekcija lokalno na uređaju
- Uvoz XLS/XLSX/CSV datoteke; novi uvoz zamjenjuje postojeći spisak
- Izvoz trenutnog stanja u XLSX

VAŽNO O UVOZU/IZVOZU
Uvoz i izvoz Excel datoteka koriste SheetJS biblioteku sa CDN adrese, pa je za te dvije
funkcije potrebna internet veza. Pregled već učitanih zaliha i lokalno čuvanje korekcija
rade bez mreže nakon prvog pokretanja. Za potpuno offline Excel uvoz potrebno je dodati
lokalnu kopiju SheetJS biblioteke.

POKRETANJE WEB VERZIJE
Otvorite www/index.html preko lokalnog web servera ili postavite sadržaj foldera www
na HTTPS hosting. Za instalaciju kao PWA otvorite adresu u Chrome-u i izaberite
Install app / Add to Home screen.

ANDROID APK
Folder android/ je Android Studio projekat koji prikazuje aplikaciju u Android WebView-u.
Otvorite folder android u Android Studio (Jellyfish ili noviji), instalirajte Android SDK
Platform 35 i sačekajte Gradle sync. Zatim izaberite Build > Build Bundle(s) / APK(s) >
Build APK(s). Za objavljivanje napravite potpisani APK preko Build > Generate Signed Bundle
or APK.

APK NIJE UKLJUČEN U OVAJ PAKET: u okruženju u kojem je projekat pripremljen nema Android
SDK/Gradle build alata, pa nije bilo moguće kompajlirati i testirati instalacioni APK.

NAPOMENA O PODACIMA
Prvi start koristi snapshot iz fajla „Stanje zaliha PO LOKACIJAMA11.11.2026.xls“.
Korekcije se čuvaju lokalno u aplikaciji. Novi Excel uvoz zamjenjuje sve postojeće redove;
prije uvoza izvezite stanje ako želite sačuvati prethodne korekcije.
