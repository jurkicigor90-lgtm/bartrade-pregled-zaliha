BARTRADE – PREGLED ZALIHA PO LOKACIJAMA
=======================================

VAŽNO: Ovaj projekat još ne sadrži gotov APK. APK se mora kompajlirati Android alatima.
Dodato je automatsko cloud build podešavanje da se APK napravi preko GitHub Actions.

KAKO DOBITI APK (bez instaliranja Android Studio na telefon):
1. Na računaru ili telefonu otvori https://github.com i napravi besplatan nalog.
2. Napravi novi prazan repository (npr. bartrade-zalihe).
3. Raspakuj ZIP i pošalji SVE fajlove i foldere iz foldera bartrade_app u repository.
   Važno: uključi i skriveni folder .github.
4. Otvori karticu Actions u repository-ju.
5. Izaberi "Build Android APK" i pritisni "Run workflow".
   (Ako je workflow pokrenut automatski nakon slanja fajlova, otvori posljednji run.)
6. Kada se završi sa zelenom oznakom, otvori taj run, pronađi Artifacts i preuzmi
   "BarTrade-Pregled-Zaliha-APK.zip".
7. Raspakuj preuzeti ZIP. Unutra je app-debug.apk. Otvori ga na Android telefonu
   i dozvoli instalaciju iz tog izvora ako Android to zatraži.

APK je debug/test izdanje, nije objavljeno na Google Play-u.
Aplikacija je zamišljena za rad bez interneta; Excel uvoz i lokalno čuvanje podataka
rade na samom telefonu.
